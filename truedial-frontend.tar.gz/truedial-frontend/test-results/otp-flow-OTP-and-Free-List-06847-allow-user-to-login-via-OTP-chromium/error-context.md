# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: otp-flow.spec.ts >> OTP and Free Listing Flow >> should allow user to login via OTP
- Location: e2e\otp-flow.spec.ts:58:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.fill: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByPlaceholder(/98765/i)

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e6]:
      - link "T truedial" [ref=e7] [cursor=pointer]:
        - /url: /
        - generic [ref=e8]: T
        - generic [ref=e9]: truedial
      - heading "Welcome back to India's fastest growing business network." [level=1] [ref=e10]
      - paragraph [ref=e11]: Access your dashboard, manage your listings, and connect with millions of customers instantly.
      - generic [ref=e12]:
        - img [ref=e13]
        - generic [ref=e16]: Secure & Encrypted Connection
    - generic [ref=e18]:
      - heading "Login to your account" [level=2] [ref=e19]
      - paragraph [ref=e20]: Enter your mobile number or email to access your TrueDial dashboard.
      - generic [ref=e21]:
        - generic [ref=e22]:
          - generic [ref=e23]:
            - text: Mobile Number
            - generic [ref=e24]:
              - img [ref=e25]
              - textbox "Enter your 10-digit mobile number" [ref=e27]
          - button "Login with OTP" [ref=e28]:
            - text: Login with OTP
            - img
        - generic [ref=e33]: Or continue with
        - button "Login with Email & Password" [ref=e34]:
          - img
          - text: Login with Email & Password
      - generic [ref=e35]:
        - text: Want to list your business?
        - link "Get a Free Listing" [ref=e36] [cursor=pointer]:
          - /url: /free-listing
  - generic [active]:
    - generic [ref=e39]:
      - generic [ref=e40]:
        - generic [ref=e41]:
          - navigation [ref=e42]:
            - button "previous" [disabled] [ref=e43]:
              - img "previous" [ref=e44]
            - generic [ref=e46]:
              - generic [ref=e47]: 1/
              - text: "1"
            - button "next" [disabled] [ref=e48]:
              - img "next" [ref=e49]
          - img
        - generic [ref=e51]:
          - link "Next.js 16.2.10 (stale) Turbopack" [ref=e52] [cursor=pointer]:
            - /url: https://nextjs.org/docs/messages/version-staleness
            - img [ref=e53]
            - generic "There is a newer version (16.2.11) available, upgrade recommended!" [ref=e55]: Next.js 16.2.10 (stale)
            - generic [ref=e56]: Turbopack
          - img
      - dialog "Build Error" [ref=e58]:
        - generic [ref=e61]:
          - generic [ref=e62]:
            - generic [ref=e63]:
              - generic [ref=e65]: Build Error
              - generic [ref=e66]:
                - button "Copy Error Info" [ref=e67] [cursor=pointer]:
                  - img [ref=e68]
                - button "No related documentation found" [disabled] [ref=e70]:
                  - img [ref=e71]
                - button "Attach Node.js inspector" [ref=e73] [cursor=pointer]:
                  - img [ref=e74]
            - generic [ref=e83]: Expected '</', got '<eof>'
          - generic [ref=e85]:
            - generic [ref=e87]:
              - img [ref=e89]
              - generic [ref=e92]: ./src/app/free-listing/page.tsx (302:1)
              - button "Open in editor" [ref=e93] [cursor=pointer]:
                - img [ref=e95]
            - generic [ref=e98]:
              - generic [ref=e99]: Expected '</', got '<eof>'
              - generic [ref=e100]: 300 |
              - generic [ref=e101]: );
              - generic [ref=e102]: 301 |
              - text: "} >"
              - generic [ref=e103]: 302 |
              - generic [ref=e104]: "|"
              - text: ^
              - generic [ref=e105]: Parsing ecmascript source code failed
        - generic [ref=e106]: "1"
        - generic [ref=e107]: "2"
    - generic [ref=e112] [cursor=pointer]:
      - button "Open Next.js Dev Tools" [ref=e113]:
        - img [ref=e114]
      - button "Open issues overlay" [ref=e118]:
        - generic [ref=e119]:
          - generic [ref=e120]: "0"
          - generic [ref=e121]: "1"
        - generic [ref=e122]: Issue
  - alert [ref=e123]
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | test.describe('OTP and Free Listing Flow', () => {
  4   |   test('should allow a business to onboard via OTP', async ({ page }) => {
  5   |     // 1. Navigate to free listing page
  6   |     await page.goto('/free-listing');
  7   |     await expect(page.getByRole('heading', { name: /Add Your Business for Free/i })).toBeVisible();
  8   | 
  9   |     // 2. Step 1: Basic Details
  10  |     await page.getByPlaceholder(/Acme Interiors/i).fill('Test Business');
  11  |     await page.getByPlaceholder(/98765 43210/i).fill('9876543210');
  12  |     await page.getByRole('button', { name: /Start Free Listing/i }).click();
  13  | 
  14  |     // 3. Step 2: OTP Verification
  15  |     await expect(page.getByRole('heading', { name: /Verify your number/i })).toBeVisible();
  16  |     // Assuming backend returns success and OTP is verified
  17  |     // We use the fixed dev OTP '123456' OR '267659' but wait, backend environment might be production.
  18  |     // If it's production, it uses a random OTP, which we can't guess easily without DB query.
  19  |     // Let's type a 6 digit code. We can mock the API response for /api/v1/truedial/auth/otp/verify!
  20  |     await page.route('**/api/v1/truedial/auth/otp/verify', route => {
  21  |       route.fulfill({
  22  |         status: 200,
  23  |         contentType: 'application/json',
  24  |         body: JSON.stringify({
  25  |           success: true,
  26  |           message: 'Logged in successfully',
  27  |           token: 'test_token',
  28  |           user: {
  29  |             id: 999,
  30  |             name: 'Test Business',
  31  |             phone: '9876543210',
  32  |             roles: [{ slug: 'business' }]
  33  |           }
  34  |         })
  35  |       });
  36  |     });
  37  | 
  38  |     await page.getByPlaceholder(/••••••/i).fill('123456');
  39  |     await page.getByRole('button', { name: /Verify OTP/i }).click();
  40  | 
  41  |     // 4. Step 3: Location
  42  |     await expect(page.getByRole('heading', { name: /Where is your business located/i })).toBeVisible();
  43  |     await page.getByPlaceholder(/Mumbai/i).fill('Mumbai');
  44  |     await page.getByPlaceholder(/Building name/i).fill('123 Test Street');
  45  |     await page.getByRole('button', { name: /Continue to Categories/i }).click();
  46  | 
  47  |     // 5. Step 4: Categories
  48  |     await expect(page.getByRole('heading', { name: /What services do you offer/i })).toBeVisible();
  49  |     await page.getByText('+ Interior Designers').click();
  50  |     await page.getByRole('button', { name: /Complete Setup/i }).click();
  51  | 
  52  |     // 6. Should redirect to dashboard/business eventually
  53  |     // We wait for the redirect
  54  |     await page.waitForURL('**/dashboard/business');
  55  |     expect(page.url()).toContain('/dashboard/business');
  56  |   });
  57  |   
  58  |   test('should allow user to login via OTP', async ({ page }) => {
  59  |     // 1. Navigate to login page
  60  |     await page.goto('/login');
  61  |     await expect(page.getByRole('heading', { name: /Login to your account/i })).toBeVisible();
  62  | 
  63  |     // 2. Mobile Number Input
> 64  |     await page.getByPlaceholder(/98765/i).fill('9876543210');
      |                                           ^ Error: locator.fill: Test timeout of 30000ms exceeded.
  65  |     
  66  |     // Mock the OTP send endpoint
  67  |     await page.route('**/api/v1/truedial/auth/otp/send', route => {
  68  |       route.fulfill({
  69  |         status: 200,
  70  |         contentType: 'application/json',
  71  |         body: JSON.stringify({ success: true })
  72  |       });
  73  |     });
  74  | 
  75  |     await page.getByRole('button', { name: /Login with OTP/i }).click();
  76  | 
  77  |     // 3. OTP Verification
  78  |     await expect(page.getByText(/OTP sent to/i)).toBeVisible();
  79  |     
  80  |     await page.route('**/api/v1/truedial/auth/otp/verify', route => {
  81  |       route.fulfill({
  82  |         status: 200,
  83  |         contentType: 'application/json',
  84  |         body: JSON.stringify({
  85  |           success: true,
  86  |           token: 'test_token',
  87  |           user: { roles: [{ slug: 'customer' }] }
  88  |         })
  89  |       });
  90  |     });
  91  | 
  92  |     await page.getByPlaceholder(/••••••/i).fill('123456');
  93  |     await page.getByRole('button', { name: /Verify & Login/i }).click();
  94  | 
  95  |     // 4. Should redirect
  96  |     await page.waitForURL('**/dashboard/user');
  97  |     expect(page.url()).toContain('/dashboard/user');
  98  |   });
  99  | });
  100 | 
```