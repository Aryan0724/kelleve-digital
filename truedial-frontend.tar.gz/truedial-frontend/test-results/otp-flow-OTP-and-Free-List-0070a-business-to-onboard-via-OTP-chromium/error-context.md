# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: otp-flow.spec.ts >> OTP and Free Listing Flow >> should allow a business to onboard via OTP
- Location: e2e\otp-flow.spec.ts:4:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: /Add Your Business for Free/i })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('heading', { name: /Add Your Business for Free/i })

```

```yaml
- navigation:
  - button "previous" [disabled]:
    - img "previous"
  - text: 1/1
  - button "next" [disabled]:
    - img "next"
- img
- link "Next.js 16.2.10 (stale) Turbopack":
  - /url: https://nextjs.org/docs/messages/version-staleness
  - img
  - text: Next.js 16.2.10 (stale) Turbopack
- img
- dialog "Build Error":
  - text: Build Error
  - button "Copy Error Info":
    - img
  - button "No related documentation found" [disabled]:
    - img
  - button "Attach Node.js inspector":
    - img
  - text: Expected '</', got '<eof>'
  - img
  - text: ./src/app/free-listing/page.tsx (302:1)
  - button "Open in editor":
    - img
  - text: "Expected '</', got '<eof>' 300 | ); 301 | } > 302 | | ^ Parsing ecmascript source code failed"
- button "Open Next.js Dev Tools":
  - img
- button "Open issues overlay": 1 Issue
- alert
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | test.describe('OTP and Free Listing Flow', () => {
  4   |   test('should allow a business to onboard via OTP', async ({ page }) => {
  5   |     // 1. Navigate to free listing page
  6   |     await page.goto('/free-listing');
> 7   |     await expect(page.getByRole('heading', { name: /Add Your Business for Free/i })).toBeVisible();
      |                                                                                      ^ Error: expect(locator).toBeVisible() failed
  8   | 
  9   |     // 2. Step 1: Basic Details
  10  |     await page.getByPlaceholder(/Acme Interiors/i).fill('Test Business');
  11  |     await page.getByPlaceholder(/98765 43210/i).fill('9876543210');
  12  |     await page.getByRole('button', { name: /Start Free Listing/i }).click();
  13  | 
  14  |     // 3. Step 2: OTP Verification
  15  |     await expect(page.getByRole('heading', { name: /Verify your number/i })).toBeVisible();
  16  |     // Assuming backend returns success and OTP is verified
  17  |     // We use the fixed dev OTP '123456' OR '267659' but wait, backend environment might be production.
  18  |     // If it's production, it uses a random OTP, which we can't guess easily without DB query.
  19  |     // Let's type a 6 digit code. We can mock the API response for /api/v1/truedial/auth/otp/verify!
  20  |     await page.route('**/api/v1/truedial/auth/otp/verify', route => {
  21  |       route.fulfill({
  22  |         status: 200,
  23  |         contentType: 'application/json',
  24  |         body: JSON.stringify({
  25  |           success: true,
  26  |           message: 'Logged in successfully',
  27  |           token: 'test_token',
  28  |           user: {
  29  |             id: 999,
  30  |             name: 'Test Business',
  31  |             phone: '9876543210',
  32  |             roles: [{ slug: 'business' }]
  33  |           }
  34  |         })
  35  |       });
  36  |     });
  37  | 
  38  |     await page.getByPlaceholder(/••••••/i).fill('123456');
  39  |     await page.getByRole('button', { name: /Verify OTP/i }).click();
  40  | 
  41  |     // 4. Step 3: Location
  42  |     await expect(page.getByRole('heading', { name: /Where is your business located/i })).toBeVisible();
  43  |     await page.getByPlaceholder(/Mumbai/i).fill('Mumbai');
  44  |     await page.getByPlaceholder(/Building name/i).fill('123 Test Street');
  45  |     await page.getByRole('button', { name: /Continue to Categories/i }).click();
  46  | 
  47  |     // 5. Step 4: Categories
  48  |     await expect(page.getByRole('heading', { name: /What services do you offer/i })).toBeVisible();
  49  |     await page.getByText('+ Interior Designers').click();
  50  |     await page.getByRole('button', { name: /Complete Setup/i }).click();
  51  | 
  52  |     // 6. Should redirect to dashboard/business eventually
  53  |     // We wait for the redirect
  54  |     await page.waitForURL('**/dashboard/business');
  55  |     expect(page.url()).toContain('/dashboard/business');
  56  |   });
  57  |   
  58  |   test('should allow user to login via OTP', async ({ page }) => {
  59  |     // 1. Navigate to login page
  60  |     await page.goto('/login');
  61  |     await expect(page.getByRole('heading', { name: /Login to your account/i })).toBeVisible();
  62  | 
  63  |     // 2. Mobile Number Input
  64  |     await page.getByPlaceholder(/98765/i).fill('9876543210');
  65  |     
  66  |     // Mock the OTP send endpoint
  67  |     await page.route('**/api/v1/truedial/auth/otp/send', route => {
  68  |       route.fulfill({
  69  |         status: 200,
  70  |         contentType: 'application/json',
  71  |         body: JSON.stringify({ success: true })
  72  |       });
  73  |     });
  74  | 
  75  |     await page.getByRole('button', { name: /Login with OTP/i }).click();
  76  | 
  77  |     // 3. OTP Verification
  78  |     await expect(page.getByText(/OTP sent to/i)).toBeVisible();
  79  |     
  80  |     await page.route('**/api/v1/truedial/auth/otp/verify', route => {
  81  |       route.fulfill({
  82  |         status: 200,
  83  |         contentType: 'application/json',
  84  |         body: JSON.stringify({
  85  |           success: true,
  86  |           token: 'test_token',
  87  |           user: { roles: [{ slug: 'customer' }] }
  88  |         })
  89  |       });
  90  |     });
  91  | 
  92  |     await page.getByPlaceholder(/••••••/i).fill('123456');
  93  |     await page.getByRole('button', { name: /Verify & Login/i }).click();
  94  | 
  95  |     // 4. Should redirect
  96  |     await page.waitForURL('**/dashboard/user');
  97  |     expect(page.url()).toContain('/dashboard/user');
  98  |   });
  99  | });
  100 | 
```